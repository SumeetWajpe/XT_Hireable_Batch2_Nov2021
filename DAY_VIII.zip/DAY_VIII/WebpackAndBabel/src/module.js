let x = 1000;

export var Add = (aVeryLargeXVariable, aVeryLargeYVariable) =>
  aVeryLargeXVariable + aVeryLargeYVariable;

export class Point {
  constructor() {
    this.x = 10;
    this.y = 10;
  }
}
