import { Point, Add } from "./module";

console.log("The addition is : " + Add(20, 30));
var point = new Point();
console.log(`[X : ${point.x}, Y : ${point.y}]`);

/* Making use of modules with webpack and babel */
