// import * as MathModule from "./Math.js";

// import Addition, { Product as Multiplication } from "./Math.js";
// console.log("The addition is : " + Addition(20, 30));
// console.log("The product is : " + Multiplication(20, 30));
